<?php get_header(); ?>
<div class="main">
	
	<? include("nav.php");?>   
	<div class="content">
		<div class="left_col">
			<div id="news">
				<!-- <img src="<?php bloginfo('template_url'); ?>/images/news.gif" vspace="0" hspace="0" border="0" class="image"><br /> -->
				<div class="section_head"><a href="/news/" class="section_title">news</a></div>
				  <?
				  wp_reset_query();	
				  query_posts(array('post__not_in'=>array(28),'category__in'=>array(1,3,6)));
				  while (have_posts()) : the_post(); ?>
				  <div class="post" id="post-<?php the_ID(); ?>">
					<h2><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php _e('Permanent Link to')?> <?php the_title(); ?>">
					  <?php the_title(); ?></a></h2>					
					<div class="entry">
					  <?php the_content(__('Continue reading &raquo;')); ?>
					</div>
				</div>
				<?
					comments_template();  
				endwhile;
				wp_reset_query();
				?>
			</div>
			<div id="photos">
				<!-- <img src="<?php bloginfo('template_url'); ?>/images/photos.gif" vspace="0" hspace="0" border="0" class="image"><br /> -->
				<div class="section_head"><a href="/photos/" class="section_title">photos</a></div>
				<? //wp_carousel(0);
				query_posts("tag=carousel");
				while (have_posts()) : the_post(); ?>
				  <div class="post" id="post-<?php the_ID(); ?>">
					<div class="entry">
					  <? the_content(__('Continue reading &raquo;')); ?>
					</div>
				</div>
				<?
				endwhile; 
				wp_reset_query();
				?><br /><br />
			</div>
		</div>
		<div class="right_col">
			<div id="videos" style="text-align:right">
				<!-- <img src="<?php bloginfo('template_url'); ?>/images/videos.gif" vspace="0" hspace="0" border="0" class="image"> -->
				<div class="section_head video_head"><a href="/videos/" class="section_title">videos</a></div>
				<object width="395" height="220">
				<param name="movie" value="http://www.youtube.com/v/tRws8o9NW5s?fs=1&amp;hl=en_US"></param>
				<param name="allowFullScreen" value="true"></param>
				<param name="allowscriptaccess" value="always"></param>
				<embed src="http://www.youtube.com/v/tRws8o9NW5s?fs=1&amp;hl=en_US" type="application/x-shockwave-flash" 
				allowscriptaccess="always" allowfullscreen="true" width="395" height="220"></embed></object><br><br>
				
				<a href="/videos">more videos...</a>
				
			</div>
			<div id="mp3s" style="text-align:right">
				<!-- <img src="<?php bloginfo('template_url'); ?>/images/mp3s2.gif" vspace="0" hspace="0" border="0" class="image"><br /> -->
				<div class="section_head"><a href="videos.php" class="section_title">mp3s</a></div>
				<ul>
					<li>Band: <a href="http://cdbaby.com/cd/flexie">Flexie</a></li>
					<li><a href="/mp3/MyRider.mp3s">My Rider</a></li>
					<li><a href="/mp3/Hyacinth.mp3s">Hyacinth</a></li>
				</ul>
				<ul>
					<li>Band: <a href="http://chemicalburnmusic.com/">Chemical Burn</a></li>
					<li><a href="/mp3s/WithinMe.m4a">Within Me</a></li>
					<li><a href="/mp3s/Leech.m4a">Leech</a></li>
					<li><a href="/mp3s/BetterOffDead.m4a">Better Off Dead</a></li>
				</ul>
				<ul>
					<li>Band: <a href="http://www.erikasimonian.com/twentynine.html">Erika Simonian</a></li>
					<li><a href="/mp3s/NYC.m4a">My Rider</a></li>
					<li><a href="/mp3s/BetweentheLines.m4a">Between the Lines</a></li>
				</ul>
				<a href="/mp3s/">more mp3s...</a>
			</div>
			<div style="text-align:right">
				<div class="section_head"><span class="section_title">about me</span></div>
				With over 27 years of experience,  15 albums, 2 years at Berklee and teachers like Joey Heredia, Dave Weckl, Steve Ferrone, Freddie Gruber, David Elitch, Jason Sutter, Rick Consadine &amp; Larry Finn, I continue to strive for a melodic approach 
	  			to the drums that best supports the artist. With a focus on time, simplicity, and dynamics, no artist is left unsatisfied.
			</div>
		</div>
		<div class="cb"></div>
	</div>
</div>
<?php get_footer(); ?>