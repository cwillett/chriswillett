<?php
if ( function_exists('register_sidebar') )
    register_sidebar(array(
        'before_widget' => '',
        'after_widget' => '',
        'before_title' => '<div class="title">',
        'after_title' => '</div>',
    ));

if ( function_exists( 'register_nav_menu' ) ) {
	register_nav_menu(array( 'topnav'=>__('Top Nav' )));
}
?>