<? wp_footer();?>
</body>
</html>